package currencyconverter2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CurrencyConverter2 extends JFrame {
    private JTextField amountField;
    private JComboBox<String> fromCurrencyComboBox;
    private JComboBox<String> toCurrencyComboBox;
    private JLabel resultLabel;
    private JTextArea feeInfoArea;

    private final String API_URL = "https://api.exchangerate-api.com/v4/latest/";

    private final String[] currencyNames = {
        "AED - United Arab Emirates Dirham", "AFN - Afghan Afghani", "ALL - Albanian Lek", "AMD - Armenian Dram", "ANG - Netherlands Antillean Guilder",
        "AOA - Angolan Kwanza", "ARS - Argentine Peso", "AUD - Australian Dollar", "AWG - Aruban Florin", "AZN - Azerbaijani Manat",
        "BAM - Bosnia-Herzegovina Convertible Mark", "BBD - Barbadian Dollar", "BDT - Bangladeshi Taka", "BGN - Bulgarian Lev", "BHD - Bahraini Dinar",
        "BIF - Burundian Franc", "BMD - Bermudian Dollar", "BND - Brunei Dollar", "BOB - Bolivian Boliviano", "BRL - Brazilian Real",
        "BSD - Bahamian Dollar", "BTN - Bhutanese Ngultrum", "BWP - Botswanan Pula", "BYN - Belarusian Ruble", "BZD - Belize Dollar",
        "CAD - Canadian Dollar", "CDF - Congolese Franc", "CHF - Swiss Franc", "CLP - Chilean Peso", "CNY - Chinese Yuan",
        "COP - Colombian Peso", "CRC - Costa Rican Colón", "CUP - Cuban Peso", "CVE - Cape Verdean Escudo", "CZK - Czech Koruna",
        "DJF - Djiboutian Franc", "DKK - Danish Krone", "DOP - Dominican Peso", "DZD - Algerian Dinar", "EGP - Egyptian Pound",
        "ERN - Eritrean Nakfa", "ETB - Ethiopian Birr", "EUR - Euro", "FJD - Fijian Dollar", "FKP - Falkland Islands Pound",
        "FOK - Faroese Króna", "GBP - British Pound", "GEL - Georgian Lari", "GGP - Guernsey Pound", "GHS - Ghanaian Cedi",
        "GIP - Gibraltar Pound", "GMD - Gambian Dalasi", "GNF - Guinean Franc", "GTQ - Guatemalan Quetzal", "GYD - Guyanese Dollar",
        "HKD - Hong Kong Dollar", "HNL - Honduran Lempira", "HRK - Croatian Kuna", "HTG - Haitian Gourde", "HUF - Hungarian Forint",
        "IDR - Indonesian Rupiah", "ILS - Israeli New Shekel", "IMP - Isle of Man Pound", "INR - Indian Rupee", "IQD - Iraqi Dinar",
        "IRR - Iranian Rial", "ISK - Icelandic Króna", "JEP - Jersey Pound", "JMD - Jamaican Dollar", "JOD - Jordanian Dinar",
        "JPY - Japanese Yen", "KES - Kenyan Shilling", "KGS - Kyrgystani Som", "KHR - Cambodian Riel", "KID - Kiribati Dollar",
        "KMF - Comorian Franc", "KRW - South Korean Won", "KWD - Kuwaiti Dinar", "KYD - Cayman Islands Dollar", "KZT - Kazakhstani Tenge",
        "LAK - Laotian Kip", "LBP - Lebanese Pound", "LKR - Sri Lankan Rupee", "LRD - Liberian Dollar", "LSL - Lesotho Loti",
        "LYD - Libyan Dinar", "MAD - Moroccan Dirham", "MDL - Moldovan Leu", "MGA - Malagasy Ariary", "MKD - Macedonian Denar",
        "MMK - Burmese Kyat", "MNT - Mongolian Tugrik", "MOP - Macanese Pataca", "MRU - Mauritanian Ouguiya", "MUR - Mauritian Rupee",
        "MVR - Maldivian Rufiyaa", "MWK - Malawian Kwacha", "MXN - Mexican Peso", "MYR - Malaysian Ringgit", "MZN - Mozambican Metical",
        "NAD - Namibian Dollar", "NGN - Nigerian Naira", "NIO - Nicaraguan Córdoba", "NOK - Norwegian Krone", "NPR - Nepalese Rupee",
        "NZD - New Zealand Dollar", "OMR - Omani Rial", "PAB - Panamanian Balboa", "PEN - Peruvian Sol", "PGK - Papua New Guinean Kina",
        "PHP - Philippine Peso", "PKR - Pakistani Rupee", "PLN - Polish Zloty", "PYG - Paraguayan Guarani", "QAR - Qatari Rial",
        "RON - Romanian Leu", "RSD - Serbian Dinar", "RUB - Russian Ruble", "RWF - Rwandan Franc", "SAR - Saudi Riyal",
        "SBD - Solomon Islands Dollar", "SCR - Seychellois Rupee", "SDG - Sudanese Pound", "SEK - Swedish Krona", "SGD - Singapore Dollar",
        "SHP - Saint Helena Pound", "SLL - Sierra Leonean Leone", "SOS - Somali Shilling", "SRD - Surinamese Dollar", "SSP - South Sudanese Pound",
        "STN - São Tomé and Príncipe Dobra", "SYP - Syrian Pound", "SZL - Eswatini Lilangeni", "THB - Thai Baht", "TJS - Tajikistani Somoni",
        "TMT - Turkmenistani Manat", "TND - Tunisian Dinar", "TOP - Tongan Paʻanga", "TRY - Turkish Lira", "TTD - Trinidad and Tobago Dollar",
        "TVD - Tuvaluan Dollar", "TWD - New Taiwan Dollar", "TZS - Tanzanian Shilling", "UAH - Ukrainian Hryvnia", "UGX - Ugandan Shilling",
        "USD - United States Dollar", "UYU - Uruguayan Peso", "UZS - Uzbekistani Som", "VES - Venezuelan Bolívar", "VND - Vietnamese Dong",
        "VUV - Vanuatu Vatu", "WST - Samoan Tala", "XAF - Central African CFA Franc", "XCD - East Caribbean Dollar", "XOF - West African CFA Franc",
        "XPF - CFP Franc", "YER - Yemeni Rial", "ZAR - South African Rand", "ZMW - Zambian Kwacha", "ZWL - Zimbabwean Dollar"
    };

    public CurrencyConverter2() {
        setTitle("Currency Converter");
        setSize(700, 650);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(176, 224, 230)); // Sky blue

        JLabel titleLabel = new JLabel("Real-Time Currency Exchange Calculator");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
        titleLabel.setForeground(Color.black);
        titleLabel.setBounds(150, 20, 700, 30);
        add(titleLabel);

        JLabel amountLabel = new JLabel("Enter Amount:");
        amountLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        amountLabel.setForeground(Color.black);
        amountLabel.setBounds(50, 80, 150, 30);
        add(amountLabel);

        amountField = new JTextField(15);
        amountField.setBounds(200, 80, 200, 30);
        add(amountField);

        JLabel fromCurrencyLabel = new JLabel("From Currency:");
        fromCurrencyLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        fromCurrencyLabel.setForeground(Color.BLACK);
        fromCurrencyLabel.setBounds(50, 130, 150, 30);
        add(fromCurrencyLabel);

        fromCurrencyComboBox = new JComboBox<>(currencyNames);
        fromCurrencyComboBox.setBounds(200, 130, 300, 30);
        add(fromCurrencyComboBox);

        JLabel toCurrencyLabel = new JLabel("To Currency:");
        toCurrencyLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        toCurrencyLabel.setForeground(Color.BLACK);
        toCurrencyLabel.setBounds(50, 180, 150, 30);
        add(toCurrencyLabel);

        toCurrencyComboBox = new JComboBox<>(currencyNames);
        toCurrencyComboBox.setBounds(200, 180, 300, 30);
        add(toCurrencyComboBox);

        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(200, 240, 100, 30);
        add(convertButton);

        resultLabel = new JLabel("Converted Amount:");
        resultLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        resultLabel.setForeground(Color.black);
        resultLabel.setBounds(50, 300, 300, 30);
        add(resultLabel);

        feeInfoArea = new JTextArea("Foreign transaction fee: 1-3% of total purchase.\n" +
            "Currency conversion fee: Charged by the ATM or card company.\n" +
            "Combined fee: May include both transaction and conversion fees.");
        feeInfoArea.setBounds(50, 350, 600, 100);
        feeInfoArea.setFont(new Font("Arial", Font.PLAIN, 16));
        feeInfoArea.setWrapStyleWord(true);
        feeInfoArea.setLineWrap(true);
        feeInfoArea.setEditable(false);
        add(feeInfoArea);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });
    }

    private void convertCurrency() {
        String amountText = amountField.getText();
        String fromCurrency = fromCurrencyComboBox.getSelectedItem().toString().split(" - ")[0];
        String toCurrency = toCurrencyComboBox.getSelectedItem().toString().split(" - ")[0];

        try {
            double amount = Double.parseDouble(amountText);
            double convertedAmount = getConvertedAmount(fromCurrency, toCurrency, amount);

            double foreignTransactionFeeRate = 0.02; // 2% fee
            double conversionFeeRate = 0.01; // 1% fee
            double foreignTransactionFee = convertedAmount * foreignTransactionFeeRate;
            double conversionFee = convertedAmount * conversionFeeRate;
            double totalFees = foreignTransactionFee + conversionFee;
            double finalAmount = convertedAmount - totalFees;

            String message = String.format(
                "Converted Amount: %.2f %s\n" +
                "Foreign Transaction Fee (2%%): %.2f %s\n" +
                "Currency Conversion Fee (1%%): %.2f %s\n" +
                "Total Fees: %.2f %s\n" +
                "Final Amount: %.2f %s",
                convertedAmount, toCurrency,
                foreignTransactionFee, toCurrency,
                conversionFee, toCurrency,
                totalFees, toCurrency,
                finalAmount, toCurrency
            );

            showMessageBox(this, message);

            // Store conversion with additional fees
            storeConversion(amount, fromCurrency, toCurrency, convertedAmount, foreignTransactionFee, conversionFee, totalFees, finalAmount);

        } catch (NumberFormatException ex) {
            resultLabel.setText("Please enter a valid amount.");
        }
    }

    private void storeConversion(double amount, String fromCurrency, String toCurrency, double convertedAmount, double foreignTransactionFee, double conversionFee, double totalFees, double finalAmount) {
        String url = "jdbc:mysql://localhost:3306/currency_converter1";
        String user = "root";
        String password = "Morya@123";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO conversions1 (amount, from_currency, to_currency, converted_amount, foreign_transaction_fee, conversion_fee, total_fees, final_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setDouble(1, amount);
            statement.setString(2, fromCurrency);
            statement.setString(3, toCurrency);
            statement.setDouble(4, convertedAmount);
            statement.setDouble(5, foreignTransactionFee);
            statement.setDouble(6, conversionFee);
            statement.setDouble(7, totalFees);
            statement.setDouble(8, finalAmount);

            statement.executeUpdate();
            feeInfoArea.setText("Conversion stored successfully in the database!");

        } catch (SQLException ex) {
            feeInfoArea.setText("Error storing conversion in the database.");
            ex.printStackTrace();
        }
    }

    private double getConvertedAmount(String fromCurrency, String toCurrency, double amount) {
        try {
            URL url = new URL(API_URL + fromCurrency);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Extract exchange rate from the response string
            String responseString = response.toString();
            int index = responseString.indexOf("\"" + toCurrency + "\":");
            if (index != -1) {
                int startIndex = index + toCurrency.length() + 3; // 3 for '":'
                int endIndex = responseString.indexOf(",", startIndex);
                double exchangeRate = Double.parseDouble(responseString.substring(startIndex, endIndex));
                return amount * exchangeRate;
            } else {
                resultLabel.setText("Error fetching conversion rate...");
                return 0;
            }

        } catch (Exception e) {
            resultLabel.setText("Error fetching conversion rate...");
            return 0;
        }
    }

    private void showMessageBox(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Conversion Result", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CurrencyConverter2().setVisible(true));
    }
}
