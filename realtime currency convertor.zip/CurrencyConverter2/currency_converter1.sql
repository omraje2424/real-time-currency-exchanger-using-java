CREATE DATABASE currency_converter1;

USE currency_converter1;

CREATE TABLE conversions1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10, 2),
    from_currency VARCHAR(10),
    to_currency VARCHAR(10),
    converted_amount DECIMAL(10, 2),
    foreign_transaction_fee DECIMAL(10, 2),  -- New column for foreign transaction fee
    conversion_fee DECIMAL(10, 2),          -- New column for currency conversion fee
    total_fees DECIMAL(10, 2),              -- New column for total fees
    final_amount DECIMAL(10, 2),            -- New column for final amount after fees
    conversion_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT * FROM conversions1;
